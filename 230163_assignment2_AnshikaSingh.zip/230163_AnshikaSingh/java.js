
let box=document.querySelector('#box');
box.addEventListener('mouseenter',()=>box.style.backgroundColor='purple')
box.addEventListener('mouseleave',()=>box.style.backgroundColor='coral')
